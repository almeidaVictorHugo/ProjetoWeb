import React from 'react';
import {Link} from 'react-router-dom';

function Login(){
    return(
        <div className="login">
            <form>
              <div>
              <h1>Login</h1>
              </div>
              <div className="form-group">
               <input type="email" placeholder="E-mail"/>
              </div>
              <div className="form-group">
                <input type="password" placeholder="Senha"/>
              </div> <br/>
              <button type='submit'>Login</button>
            </form> <br/>
            <Link to="/Cadastro">Não possui uma conta?</Link>
        </div>
    );
}

export default Login;
