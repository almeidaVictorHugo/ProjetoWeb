import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import firebase from '../ConexaoDb';
import 'firebase/storage';

class Cadastrar extends Component{
    constructor(props){
        super(props);
        this.state = {
            nome: '', 
            email: '',
            senha: '',
            confirmarSenha: '',
        };

        this.cadastrar = this.cadastrar.bind(this);
      
        //firebase.auth().signOut();
        /*
        firebase.auth().onAuthStateChanged((user) => {
            if(user){
            firebase.database().ref('usuario').child(user.uid).set({
                nome:this.state.nome,
                email: this.state.email,
            })
            .then(()=>{
                this.setState({
                nome:'',
                email:'',
                senha:''
                })
            });
            }
        });
        */
    }

        cadastrar(e){
            firebase.auth().createUserWithEmailAndPassword(this.state.email, this.state.senha)
            .catch((error) => {
                alert(error.code);
            })
            e.preventDefault();
        }
    

    render(){
        return(
            <div className="cadastro">
                <form onSubmit={this.cadastrar}>
                <h1>Cadastro</h1>
                <div className="form-group">
                    <input type="text" placeholder="Nome" onChange={(e) => this.setState({nome:e.target.value})}/>
                </div>
                <div className="form-group">
                    <input type="email" placeholder="E-mail" onChange={(e) => this.setState({email:e.target.value})}/>
                </div>
                <div className="form-group">
                    <input type="password" placeholder="Senha" onChange={(e) => this.setState({senha:e.target.value})}/> <br/>
                    <input type="password" placeholder="Confirmar senha" onChange={(e) => this.setState({confirmarSenha:e.target.value})}/>
                </div><br/>
                <div className="form-group">
                    Data de nascimento: <br/>
                    <input type="date"/>
                </div>
                <div className="form-group">
                    Sexo:
                    <input type="radio" name="sexo"/> Masculino <input type="radio" name="sexo"/> Feminino
                </div> <br/>
                
                <button type="submit">Cadastrar</button>
                </form> <br/>
                <Link to="/Login">Já Possui uma conta?</Link>
            </div>
        );
    }
}

export default Cadastrar;